---------------------------------------------------------------------------------
These simple utilities are Copyright 2012 Bradley G. Miller. All rights reserved.
---------------------------------------------------------------------------------

These may be used by anyone in any setting (home/commercial/nonprofit) and may be
redistributed provided there is no charge/fee for them and all files are kept
in the original distribution form. There is no warranty of any kind supplied or
implied.

I use these when working in WinPE 3.X from a bootable USB drive They have proven
very useful and perhaps you will also find them useful. They are written to
function properly with WinPE 3.x and not meant for your Windows install. They
will work in Windows but they are truly meant for WinPE 3.x.

Please read the readme.txt file in each folder to understand how to use if you
decide to use the apploader.exe on your bootable USB drive. Using the apploader
is not necessary, you can simply put the version(s) you need on your USB drive.
The advantage to using this is once you have mounted your boot.wim and copied
the files to their proper places you can just edit the apploader.ini to point to
a different application you might want to start on boot up. No more mounting the
the boot.wim to point to a different start up application.

When using the file managers please use the Map Network Drive and Disconnect
Network Drive from the menu. This will refresh the drive additions properly. If
you use Net Use from the Command window to map then hit F5 afterwads to refresh
the tree. This holds true for using the Pathbar also to connect to a remote drive.
F5 is your best friend if the drive is not showing up after mapped or still there
if you disconnected with Net Use.(right click disconnect drive then F5)

Once you have the text editor open just drop file on it to load. It will come to
the top for editing.

I know this is pretty terse but writing help is not something I enjoy doing.
Sorry about that. But for those that use WinPE this should all makes sense, I
hope. If not send email to pe@a43filemanager.com and I will try to assist.

Any further development depends on user feedback. I am fine with the way these
function now as they get me through the day working on dead machines. 

Side note:
---------- 
To get feedback from file progress (copying/deleting) you must copy
the shellstyle.dll from your Windows machine and place it in the System32 folder
of your boot.wim. If it is not there the dialogs will not appear. Ensure to use
the correct shellstyle.dll for x86 or x64.  

------------------------------------------------------------------------------
The 7z.dll is Copyright (C) 2011 Igor Pavlov. Many thanks to him for his great
lzma work. Visit 7-Zip here: http://www.7-zip.org/faq.html
------------------------------------------------------------------------------

Files in original distribution:
-------------------------------
x64
 ->FileManagers
   7z.dll 
   FileManagerPE.exe
   TextEditorPE.exe
   readme.txt
   ->Program Files
     ->apploader
       apploader.exe
       MYPE.reg
       readme.txt
   ->System32                 
     startnet.cmd
     readme.txt
   ->USB_DRIVE_ROOT
     apploader.ini
     readme.txt
     Unattend.xml

x86
 ->FileManagers
   7z.dll 
   FileManagerPE.exe
   TextEditorPE.exe
   readme.txt
   ->Program Files
     ->apploader
       apploader.exe
       MYPE.reg
       readme.txt
   ->System32                 
     startnet.cmd
     readme.txt
   ->USB_DRIVE_ROOT
     apploader.ini
     readme.txt
     Unattend.xml                                           
-------------------------------

His peace upon all...
B. G. Miller





              