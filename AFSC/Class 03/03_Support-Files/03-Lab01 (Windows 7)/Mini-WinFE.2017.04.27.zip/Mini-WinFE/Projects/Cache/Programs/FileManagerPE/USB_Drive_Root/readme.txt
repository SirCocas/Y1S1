
These 2 files go in the root of your USB drive.

apploader.ini
-------------
This initialization file points to where the application is stored on your USB
drive. 

Example:
[Loader]
App=FileManagers\x64\FileManagerPE.exe
App= the application to start on boot up.
Notice there is no backslash before the folder FileManagers\x64 which will start
the FileManagerPE.exe application. 

Unattend.xml
------------
This file sets your screen resolution to something usable. You can experiment
with higher resolutions if you like by editing it.
Example:
          <Display>
          <ColorDepth>16</ColorDepth>
          <HorizontalResolution>1024</HorizontalResolution>
          <RefreshRate>60</RefreshRate>
          <VerticalResolution>768</VerticalResolution>
          </Display>
Try 32 for ColorDepth, 1280 for HorizontalResolution and 600 for VerticalResolution.
This of course depends on what grahic chip you have but the default in the example
should be fine.

Note: The Unattend.xml file is different for x86 and x64 so use the one in the
proper folder as to which you are booting. 
