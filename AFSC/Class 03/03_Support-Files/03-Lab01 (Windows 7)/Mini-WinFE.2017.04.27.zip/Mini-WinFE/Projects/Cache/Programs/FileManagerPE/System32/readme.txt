
Put this file, startnet.cmd, in the System32 folder of your mounted boot.wim.
You should already have this file there so just add the 2 lines after wpeinit.

It contains the following:

wpeinit
------- 
This will already be in your startnet.cmd file. Starts your PE session.

regedit /s "X:\Program Files\apploader\MYPE.reg"
------------------------------------------------ 
This registry file will set the registry to show hidden files.

"X:\Program Files\apploader\apploader.exe" 
------------------------------------------
This starts the apploader.exe. It looks for an apploader.ini in the root of your
USB drive. You can rename it but ensure you name your .ini file accordingly as
apploader.exe looks for an .ini with the same name.

Example: 
Rename apploader.exe to loadapp.exe it will look for loadapp.ini in the root of
your USB drive. 
