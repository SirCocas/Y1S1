
These 2 files are the ones pointed to in your startnet.cmd file.
Ensure they are where startnet.cmd points to them.