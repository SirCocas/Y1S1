SumatraPDF x86/x64 Optimized Builds
More information at http://guti.is-great.org/static.php?page=SumatraPDFOpt

SumatraPDF prerelease optimized build:
- Added x64 compile for native x64 systems.
- Compiled with Visual C++ 2012 RC instead of Visual C++ 2008 to achieve better quality code (32 bit executable is 4,362 Kb. instead of 4,364 Kb. in the official compile).
- Compiled with /fp:fast to increase floating-point operations performance at the cost of some precision loss not noticeable on SumatraPDFOpt.
- Compiled with /Zp16 to get faster code when accesing data structures specially on newer CPU.
- Compiled with /GA to get faster and smaller threading code.
- Compiled with /GS- to get faster and smaller variable accessing.
- Compiled with /favor:blend to get a good execution speed in both AMD and Intel x64 CPUs.
- Compiled with /vmb to get faster and smaller acceses to objects.
- Compiled with /QIfist 
- Linked with /opt:icf,4 to remove duplicate code in resulting executables.
- Linked with /LARGEADDRESSAWARE to support addresses of up to 3 Gb. in x86 processors.
- Linked with /WS:AGGRESSIVE to agressively reduce memory usage when inactive.
- ZIP package created with KZIP 14/04/2007 to reduce distribution size.
- Added pre-release branding that was missing in my latest builds.
- Separate builds for x86 generic, x86 SSE, x86 SSE2 and x64 generic (x64 AMD and x64 Intel generate exactly the same code).
- Separate downloads per each optimized architecture.
- Remaped check for updates URLs.
- Downloads moved from Megaupload to website server.
- Identified builds by the name Sumatra PDF Opt.
- Added credit section on About dialog.
- x64 SIMD accelerated JPEG Turbo decoding.
- Optimization flags applied over more sets (Fitz, Freetype, libjpeg, ...).
- Added -O9 NASM optimization flag.
- Using Profile Guided Optimizations (PGO) for all builds builds. 200 KB smaller, and 10% faster.
- Activated BLACK_ON_YELLOW.
- Linked with ASMLib 2.30 by Agner Fog (http://www.agner.org/optimize/) to get a slight speed increase and merory usage reduce.
- Since http://nikkhokkho.sourceforge.net is the new permanent URL, all internal links has been properly updated.
- Upgraded to NASM 2.10.03 with some x64 optimizations.
- Synctex enhancements enabled again as per popular request.
- Upgraded to VC++ 2012 that should fix SSE builds requiring SSE2, and improve overall stability and performance.
- Executables compressed with MPRESS 2.19 with s compression, instead of UPX 3.07 to reduce executable size (32 bit executable is once compressed 1,650 Kb. instead of 2,105 Kb. in the official compile).
- Compiled with libjpeg-turbo 1.3 pre-beta r856.
- Compiled with /GF to pool common strings making executable smaller.
- Added PGO instrumentation for XPS, CBZ, CBR and DjVu files too. Optimized functions grow from 19% to 23%.
- Enabled colored SumatraPDFOpt in main window.
- Included SumatraPDF.chm multilanguage help file (English, Chinese, Spanish, Japanese, Portuguese, Russian, German and Romanian).
- Built with experimental ribbon interface (removed as of r4848).
- Based on SumatraPDF 2.2 r6623 (2012-09-09) code base.


Features now available in official version: 
- Linked with /RELEASE to generate a checksum that will make easy detecting corruption in the program due to malware attacks.
- Built with CHM support.